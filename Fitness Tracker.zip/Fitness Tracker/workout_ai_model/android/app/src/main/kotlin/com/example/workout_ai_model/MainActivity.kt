package com.example.workout_ai_model

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
